package com.mealkit.main;

public class ServiceException extends RuntimeException {

	public ServiceException(int ucId, Exception cause) {

	}

}